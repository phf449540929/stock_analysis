import pytest, fastai

#I'm all empty, please fill me with tests about the functions in layers.py